// Necesito 'dart:io' para leer y escribir en la consola (stdin y stdout).
import 'dart:io';

// Importo las constantes, como la variable global LIST.
import '../constants/CONSTANTS.dart';
// Importo el modelo para poder usar el tipo 'Card'.
import '../logic/Card.dart';

// Hago este fichero 'View' público para que se pueda importar desde otro lado.
export 'View.dart';

// Muestra el menú principal y devuelve la opción elegida por el usuario.
int showMenu() {
  stdout.write("1. Añadir carta\n");
  stdout.write("2. Modificar carta\n");
  stdout.write("3. Eliminar carta\n");
  stdout.write("4. Listar cartas\n");
  stdout.write("5. Buscar cartas\n");
  stdout.write("6. Escribir en json\n");
  stdout.write("7. Ler de un json\n");
  stdout.write("8. Salir\n");

  // Leo la línea, y si no se puede convertir a número, devuelvo -1 como error.
  return int.tryParse(stdin.readLineSync() ?? "") ?? -1;
}

// Pide al usuario los datos para una nueva carta y la añade a la lista.
addCard() {
  print("Introduce el nombre de la carta:");
  String nombre = stdin.readLineSync() ?? "";
  print("Introduce la calidad de la carta");
  String? calidad = stdin.readLineSync(); // Calidad puede ser nula.
  print("Introduce la coleccion de la carta");
  String coleccion = stdin.readLineSync() ?? "";
  print("Introduce el precio de la carta");
  double precio = double.tryParse(stdin.readLineSync() ?? "") ?? -1;

  // Llamo a la función de la lista para que la añada.
  LIST.addCard(nombre, calidad, coleccion, precio);
}

// Lógica para modificar una carta existente.
modCard() {
  // Primero muestro todas las cartas para que el usuario elija cuál modificar.
  print(LIST);
  print("Introduce el codigo de la carta que quieras modificar");
  int cod = int.tryParse(stdin.readLineSync() ?? "") ?? -1;

  // Busco la carta por el código.
  Card? card;
  try {
    // searchCard devuelve una lista, yo quiero el primer (y único) elemento.
    // El try-catch es para evitar que se rompa si la lista que devuelve está vacía.
    card = LIST.searchCard(code: cod)[0];
  } catch (e) {
    // Si falla la búsqueda, la carta se queda en null.
    card = null;
  }

  // Si encontré la carta, procedo a modificarla.
  if (card != null) {
    late String dato;
    // Para cada campo, pido el nuevo dato. Si el usuario no escribe nada, mantengo el valor antiguo.
    print(
      "Introduce el nuevo nombre de la carta: (deja vacio. para no modificar)",
    );
    dato = stdin.readLineSync() ?? "";
    if (dato != "") {
      card.nombre = dato;
    }

    print(
      "Introduce la nueva calidad de la carta (deja vacio. para no modificar)",
    );
    dato = stdin.readLineSync() ?? "";
    if (dato != "") {
      card.calidad = dato;
    }
    print(
      "Introduce la nueva coleccion de la carta (deja vacio. para no modificar)",
    );
    // Aquí uso un operador ternario, es una forma más corta de hacer el if/else.
    card.coleccion = (dato = stdin.readLineSync() ?? "") == ""
        ? card.coleccion
        : dato;

    print(
      "Introduce el nuevo precio de la carta (deja vacio. para no modificar)",
    );
    // Si tryParse falla (porque no es un número), devuelvo el precio que ya tenía.
    card.precio = double.tryParse(stdin.readLineSync() ?? "") ?? card.precio;
  } else {
    // Si no se encuentra la carta, aviso al usuario.
    print("La carta no existe");
  }
}

// Pide al usuario los filtros y busca en la lista.
searchCard() {
  print(
    "Introduce el nombre de la carta (deja vacio. para no buscarpor el valor)",
  );
  String nombre = stdin.readLineSync() ?? "";
  print(
    "Introduce la calidad de la carta (deja vacio. para no buscarpor el valor)",
  );
  String calidad = stdin.readLineSync() ?? "";
  print(
    "Introduce la coleccion de la carta (deja vacio. para no buscarpor el valor)",
  );
  String coleccion = stdin.readLineSync() ?? "";
  print(
    "Introduce el precio de la carta (deja vacio. para no buscarpor el valor)",
  );
  double precio = double.tryParse(stdin.readLineSync() ?? "") ?? -1;

  // Paso los filtros al método de búsqueda de la lista.
  return LIST.searchCard(
    nombre: nombre,
    calidad: calidad,
    coleccion: coleccion,
    precio: precio,
  );
}

// Función principal que arranca y controla la aplicación.
void app() async {
  // Añado unas cuantas cartas al principio para tener datos de prueba.
  LIST.addCard("Underground sea", "Excelent", "Revised", 600.00);

  LIST.addCard("Yawgmoth`s will", "Played", "Saga de Urza", 90.00);

  LIST.addCard("Mox Diamond", "Excelent", "Portal", 500.00);

  int? op;

  // Bucle principal de la aplicación, se ejecuta hasta que el usuario elija la opción 8.
  while (op != 8) {
    op = showMenu();

    // El switch dirige al usuario a la función correspondiente según su elección.
    switch (op) {
      case 1:
        addCard();
      case 2:
        modCard();
      case 3:
        print(LIST);
        print("Introduce el codigo de una carta");
        // Leo el código que el usuario quiere borrar.
        int code = int.tryParse(stdin.readLineSync() ?? "") ?? -1;
        LIST.delCard(code);
      case 4:
        print(LIST);
      case 5:
        print(searchCard());
      case 6:
        // El 'await' es necesario porque writeInJson es una función asíncrona.
        await LIST.writeInJson("cards.json");
      case 7:
        await LIST.readFromJson("cards.json");
    }
  }
}
