// Importo el fichero 'View.dart' que contiene toda la lógica de la interfaz.
import 'views/View.dart';

// Esta es la función principal, el punto de entrada de la aplicación.
void main(List<String> args) {
  // Lo único que hace es llamar a la función 'app' para que empiece todo.
  app();
}
