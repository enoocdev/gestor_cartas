// Importo la clase que gestiona la lista de cartas.
import '../logic/CardList.dart';
// Exporto este mismo fichero para que la constante LIST sea accesible desde otros sitios.
export 'CONSTANTS.dart';

// Creo LA instancia única y global de la lista de cartas.
// Es 'final' para asegurar que siempre sea la misma lista y no se reemplace por accidente.

final Cardlist LIST = Cardlist();
